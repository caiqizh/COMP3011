#include "naive_rmq.hpp"
#include "rmq_test.hpp"

TEST_IMPL(naive_rmq)
