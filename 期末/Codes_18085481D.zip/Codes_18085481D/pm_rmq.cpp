#include "pm_rmq.hpp"
#include "pm_rmq_test.hpp"

TEST_IMPL(pm_rmq)
