#include "sparse_rmq.hpp"
#include "rmq_test.hpp"

TEST_IMPL(sparse_rmq)
