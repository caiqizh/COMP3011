#include "opt_rmq.hpp"
#include "rmq_test.hpp"

TEST_IMPL(opt_rmq)
